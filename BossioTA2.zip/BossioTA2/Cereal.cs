﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BossioTA2
{
    class Cereal
    {
        // getters and setters for cereal properties
        public string Name { get; set; }
        public char Mfr { get; set; }
        public char Type { get; set; }
        public int Calories { get; set; }
        public int Protien { get; set; }
        public int Fat { get; set; }
        public int Sodium { get; set; }
        public double Fiber { get; set; }
        public double Carbo { get; set; }
        public int Sugars { get; set; }
        public int Potass { get; set; }
        public int Vitamins { get; set; }
        public int Shelf { get; set; }
        public double Weight { get; set; }
        public double Cups { get; set; }
        public double Rating { get; set; }

        // cereal constructor
        public Cereal(string name, char mfr, char type, int calories, int protien, int fat, int sodium, double fiber, double carb,
            int sugar, int potass, int vitamins, int shelf, double weight, double cups, double rating)
        {
            Name = name;
            Mfr = mfr;
            Type = type;
            Calories = calories;
            Protien = protien;
            Fat = fat;
            Sodium = sodium;
            Fiber = fiber;
            Carbo = carb;
            Sugars = sugar;
            Potass = potass;
            Vitamins = vitamins;
            Shelf = shelf;
            Weight = weight;
            Cups = cups;
            Rating = rating;
        }
    }
}
