﻿
namespace BossioTA2
{
    partial class CerealKiller
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CerealKiller));
            this.cerealGrid = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mfr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calories = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.protein = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sodium = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fiber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carbs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sugars = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.potassium = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vitamins = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cups = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rating = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.equalButton4 = new System.Windows.Forms.RadioButton();
            this.valueBox4 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lessButton4 = new System.Windows.Forms.RadioButton();
            this.greaterButton4 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.searchByBox4 = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.equalButton3 = new System.Windows.Forms.RadioButton();
            this.valueBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lessButton3 = new System.Windows.Forms.RadioButton();
            this.greaterButton3 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.searchByBox3 = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.equalButton2 = new System.Windows.Forms.RadioButton();
            this.valueBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lessButton2 = new System.Windows.Forms.RadioButton();
            this.greaterButton2 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.searchByBox2 = new System.Windows.Forms.ComboBox();
            this.equalButton = new System.Windows.Forms.RadioButton();
            this.valueBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lessButton = new System.Windows.Forms.RadioButton();
            this.greaterButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.searchByBox = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.reverseButton = new System.Windows.Forms.RadioButton();
            this.searchButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.cerealGrid)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cerealGrid
            // 
            this.cerealGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cerealGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.mfr,
            this.type,
            this.calories,
            this.protein,
            this.fat,
            this.sodium,
            this.fiber,
            this.carbs,
            this.sugars,
            this.potassium,
            this.vitamins,
            this.shelf,
            this.weight,
            this.cups,
            this.rating});
            this.cerealGrid.Location = new System.Drawing.Point(50, 178);
            this.cerealGrid.Name = "cerealGrid";
            this.cerealGrid.RowHeadersWidth = 62;
            this.cerealGrid.RowTemplate.Height = 33;
            this.cerealGrid.Size = new System.Drawing.Size(1790, 452);
            this.cerealGrid.TabIndex = 0;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.MinimumWidth = 8;
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 350;
            // 
            // mfr
            // 
            this.mfr.HeaderText = "MFR";
            this.mfr.MinimumWidth = 8;
            this.mfr.Name = "mfr";
            this.mfr.ReadOnly = true;
            this.mfr.Width = 50;
            // 
            // type
            // 
            this.type.HeaderText = "Type";
            this.type.MinimumWidth = 8;
            this.type.Name = "type";
            this.type.ReadOnly = true;
            this.type.Width = 50;
            // 
            // calories
            // 
            this.calories.HeaderText = "Calories";
            this.calories.MinimumWidth = 8;
            this.calories.Name = "calories";
            this.calories.ReadOnly = true;
            this.calories.Width = 150;
            // 
            // protein
            // 
            this.protein.HeaderText = "Protein";
            this.protein.MinimumWidth = 8;
            this.protein.Name = "protein";
            this.protein.ReadOnly = true;
            this.protein.Width = 75;
            // 
            // fat
            // 
            this.fat.HeaderText = "Fat";
            this.fat.MinimumWidth = 8;
            this.fat.Name = "fat";
            this.fat.ReadOnly = true;
            this.fat.Width = 75;
            // 
            // sodium
            // 
            this.sodium.HeaderText = "Sodium";
            this.sodium.MinimumWidth = 8;
            this.sodium.Name = "sodium";
            this.sodium.ReadOnly = true;
            this.sodium.Width = 150;
            // 
            // fiber
            // 
            this.fiber.HeaderText = "Fiber";
            this.fiber.MinimumWidth = 8;
            this.fiber.Name = "fiber";
            this.fiber.ReadOnly = true;
            this.fiber.Width = 75;
            // 
            // carbs
            // 
            this.carbs.HeaderText = "Carbs";
            this.carbs.MinimumWidth = 8;
            this.carbs.Name = "carbs";
            this.carbs.ReadOnly = true;
            this.carbs.Width = 75;
            // 
            // sugars
            // 
            this.sugars.HeaderText = "Sugars";
            this.sugars.MinimumWidth = 8;
            this.sugars.Name = "sugars";
            this.sugars.ReadOnly = true;
            this.sugars.Width = 150;
            // 
            // potassium
            // 
            this.potassium.HeaderText = "Potassium";
            this.potassium.MinimumWidth = 8;
            this.potassium.Name = "potassium";
            this.potassium.ReadOnly = true;
            this.potassium.Width = 75;
            // 
            // vitamins
            // 
            this.vitamins.HeaderText = "Vitamins";
            this.vitamins.MinimumWidth = 8;
            this.vitamins.Name = "vitamins";
            this.vitamins.ReadOnly = true;
            this.vitamins.Width = 75;
            // 
            // shelf
            // 
            this.shelf.HeaderText = "Shelf";
            this.shelf.MinimumWidth = 8;
            this.shelf.Name = "shelf";
            this.shelf.ReadOnly = true;
            this.shelf.Width = 75;
            // 
            // weight
            // 
            this.weight.HeaderText = "Weight";
            this.weight.MinimumWidth = 8;
            this.weight.Name = "weight";
            this.weight.ReadOnly = true;
            this.weight.Width = 75;
            // 
            // cups
            // 
            this.cups.HeaderText = "Cups";
            this.cups.MinimumWidth = 8;
            this.cups.Name = "cups";
            this.cups.ReadOnly = true;
            this.cups.Width = 75;
            // 
            // rating
            // 
            this.rating.HeaderText = "Rating";
            this.rating.MinimumWidth = 8;
            this.rating.Name = "rating";
            this.rating.ReadOnly = true;
            this.rating.Width = 150;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.equalButton);
            this.groupBox1.Controls.Add(this.valueBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lessButton);
            this.groupBox1.Controls.Add(this.greaterButton);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.searchByBox);
            this.groupBox1.Location = new System.Drawing.Point(80, 652);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1221, 363);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.equalButton4);
            this.panel4.Controls.Add(this.valueBox4);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.lessButton4);
            this.panel4.Controls.Add(this.greaterButton4);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.searchByBox4);
            this.panel4.Location = new System.Drawing.Point(605, 178);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(390, 163);
            this.panel4.TabIndex = 19;
            // 
            // equalButton4
            // 
            this.equalButton4.AutoSize = true;
            this.equalButton4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.equalButton4.Location = new System.Drawing.Point(237, 114);
            this.equalButton4.Name = "equalButton4";
            this.equalButton4.Size = new System.Drawing.Size(90, 34);
            this.equalButton4.TabIndex = 16;
            this.equalButton4.TabStop = true;
            this.equalButton4.Text = "Equal";
            this.equalButton4.UseVisualStyleBackColor = true;
            // 
            // valueBox4
            // 
            this.valueBox4.Location = new System.Drawing.Point(165, 63);
            this.valueBox4.Name = "valueBox4";
            this.valueBox4.Size = new System.Drawing.Size(162, 31);
            this.valueBox4.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 25);
            this.label8.TabIndex = 14;
            this.label8.Text = "Value Search : ";
            // 
            // lessButton4
            // 
            this.lessButton4.AutoSize = true;
            this.lessButton4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lessButton4.Location = new System.Drawing.Point(137, 114);
            this.lessButton4.Name = "lessButton4";
            this.lessButton4.Size = new System.Drawing.Size(78, 34);
            this.lessButton4.TabIndex = 13;
            this.lessButton4.TabStop = true;
            this.lessButton4.Text = "Less";
            this.lessButton4.UseVisualStyleBackColor = true;
            // 
            // greaterButton4
            // 
            this.greaterButton4.AutoSize = true;
            this.greaterButton4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.greaterButton4.Location = new System.Drawing.Point(20, 114);
            this.greaterButton4.Name = "greaterButton4";
            this.greaterButton4.Size = new System.Drawing.Size(111, 34);
            this.greaterButton4.TabIndex = 12;
            this.greaterButton4.TabStop = true;
            this.greaterButton4.Text = "Greater";
            this.greaterButton4.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Search By: ";
            // 
            // searchByBox4
            // 
            this.searchByBox4.FormattingEnabled = true;
            this.searchByBox4.Items.AddRange(new object[] {
            "Calories",
            "Protein",
            "Fat",
            "Sodium",
            "Fiber",
            "Carbs",
            "Sugars",
            "Potassium",
            "Vitamins",
            "Rating"});
            this.searchByBox4.Location = new System.Drawing.Point(137, 15);
            this.searchByBox4.Name = "searchByBox4";
            this.searchByBox4.Size = new System.Drawing.Size(190, 33);
            this.searchByBox4.TabIndex = 10;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.equalButton3);
            this.panel3.Controls.Add(this.valueBox3);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.lessButton3);
            this.panel3.Controls.Add(this.greaterButton3);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.searchByBox3);
            this.panel3.Location = new System.Drawing.Point(102, 178);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(390, 163);
            this.panel3.TabIndex = 18;
            // 
            // equalButton3
            // 
            this.equalButton3.AutoSize = true;
            this.equalButton3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.equalButton3.Location = new System.Drawing.Point(237, 114);
            this.equalButton3.Name = "equalButton3";
            this.equalButton3.Size = new System.Drawing.Size(90, 34);
            this.equalButton3.TabIndex = 16;
            this.equalButton3.TabStop = true;
            this.equalButton3.Text = "Equal";
            this.equalButton3.UseVisualStyleBackColor = true;
            // 
            // valueBox3
            // 
            this.valueBox3.Location = new System.Drawing.Point(165, 63);
            this.valueBox3.Name = "valueBox3";
            this.valueBox3.Size = new System.Drawing.Size(162, 31);
            this.valueBox3.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 25);
            this.label6.TabIndex = 14;
            this.label6.Text = "Value Search : ";
            // 
            // lessButton3
            // 
            this.lessButton3.AutoSize = true;
            this.lessButton3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lessButton3.Location = new System.Drawing.Point(137, 114);
            this.lessButton3.Name = "lessButton3";
            this.lessButton3.Size = new System.Drawing.Size(78, 34);
            this.lessButton3.TabIndex = 13;
            this.lessButton3.TabStop = true;
            this.lessButton3.Text = "Less";
            this.lessButton3.UseVisualStyleBackColor = true;
            // 
            // greaterButton3
            // 
            this.greaterButton3.AutoSize = true;
            this.greaterButton3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.greaterButton3.Location = new System.Drawing.Point(20, 114);
            this.greaterButton3.Name = "greaterButton3";
            this.greaterButton3.Size = new System.Drawing.Size(111, 34);
            this.greaterButton3.TabIndex = 12;
            this.greaterButton3.TabStop = true;
            this.greaterButton3.Text = "Greater";
            this.greaterButton3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "Search By: ";
            // 
            // searchByBox3
            // 
            this.searchByBox3.FormattingEnabled = true;
            this.searchByBox3.Items.AddRange(new object[] {
            "Calories",
            "Protein",
            "Fat",
            "Sodium",
            "Fiber",
            "Carbs",
            "Sugars",
            "Potassium",
            "Vitamins",
            "Rating"});
            this.searchByBox3.Location = new System.Drawing.Point(137, 15);
            this.searchByBox3.Name = "searchByBox3";
            this.searchByBox3.Size = new System.Drawing.Size(190, 33);
            this.searchByBox3.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.equalButton2);
            this.panel2.Controls.Add(this.valueBox2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lessButton2);
            this.panel2.Controls.Add(this.greaterButton2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.searchByBox2);
            this.panel2.Location = new System.Drawing.Point(605, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(390, 151);
            this.panel2.TabIndex = 17;
            // 
            // equalButton2
            // 
            this.equalButton2.AutoSize = true;
            this.equalButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.equalButton2.Location = new System.Drawing.Point(237, 114);
            this.equalButton2.Name = "equalButton2";
            this.equalButton2.Size = new System.Drawing.Size(90, 34);
            this.equalButton2.TabIndex = 16;
            this.equalButton2.TabStop = true;
            this.equalButton2.Text = "Equal";
            this.equalButton2.UseVisualStyleBackColor = true;
            // 
            // valueBox2
            // 
            this.valueBox2.Location = new System.Drawing.Point(165, 63);
            this.valueBox2.Name = "valueBox2";
            this.valueBox2.Size = new System.Drawing.Size(162, 31);
            this.valueBox2.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "Value Search : ";
            // 
            // lessButton2
            // 
            this.lessButton2.AutoSize = true;
            this.lessButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lessButton2.Location = new System.Drawing.Point(137, 114);
            this.lessButton2.Name = "lessButton2";
            this.lessButton2.Size = new System.Drawing.Size(78, 34);
            this.lessButton2.TabIndex = 13;
            this.lessButton2.TabStop = true;
            this.lessButton2.Text = "Less";
            this.lessButton2.UseVisualStyleBackColor = true;
            // 
            // greaterButton2
            // 
            this.greaterButton2.AutoSize = true;
            this.greaterButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.greaterButton2.Location = new System.Drawing.Point(20, 114);
            this.greaterButton2.Name = "greaterButton2";
            this.greaterButton2.Size = new System.Drawing.Size(111, 34);
            this.greaterButton2.TabIndex = 12;
            this.greaterButton2.TabStop = true;
            this.greaterButton2.Text = "Greater";
            this.greaterButton2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "Search By: ";
            // 
            // searchByBox2
            // 
            this.searchByBox2.FormattingEnabled = true;
            this.searchByBox2.Items.AddRange(new object[] {
            "Calories",
            "Protein",
            "Fat",
            "Sodium",
            "Fiber",
            "Carbs",
            "Sugars",
            "Potassium",
            "Vitamins",
            "Rating"});
            this.searchByBox2.Location = new System.Drawing.Point(137, 15);
            this.searchByBox2.Name = "searchByBox2";
            this.searchByBox2.Size = new System.Drawing.Size(190, 33);
            this.searchByBox2.TabIndex = 10;
            // 
            // equalButton
            // 
            this.equalButton.AutoSize = true;
            this.equalButton.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.equalButton.Location = new System.Drawing.Point(354, 120);
            this.equalButton.Name = "equalButton";
            this.equalButton.Size = new System.Drawing.Size(90, 34);
            this.equalButton.TabIndex = 9;
            this.equalButton.TabStop = true;
            this.equalButton.Text = "Equal";
            this.equalButton.UseVisualStyleBackColor = true;
            // 
            // valueBox
            // 
            this.valueBox.Location = new System.Drawing.Point(259, 66);
            this.valueBox.Name = "valueBox";
            this.valueBox.Size = new System.Drawing.Size(185, 31);
            this.valueBox.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(121, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Value Search : ";
            // 
            // lessButton
            // 
            this.lessButton.AutoSize = true;
            this.lessButton.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lessButton.Location = new System.Drawing.Point(245, 120);
            this.lessButton.Name = "lessButton";
            this.lessButton.Size = new System.Drawing.Size(78, 34);
            this.lessButton.TabIndex = 6;
            this.lessButton.TabStop = true;
            this.lessButton.Text = "Less";
            this.lessButton.UseVisualStyleBackColor = true;
            // 
            // greaterButton
            // 
            this.greaterButton.AutoSize = true;
            this.greaterButton.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.greaterButton.Location = new System.Drawing.Point(121, 120);
            this.greaterButton.Name = "greaterButton";
            this.greaterButton.Size = new System.Drawing.Size(111, 34);
            this.greaterButton.TabIndex = 5;
            this.greaterButton.TabStop = true;
            this.greaterButton.Text = "Greater";
            this.greaterButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search By: ";
            // 
            // searchByBox
            // 
            this.searchByBox.FormattingEnabled = true;
            this.searchByBox.Items.AddRange(new object[] {
            "Calories",
            "Protein",
            "Fat",
            "Sodium",
            "Fiber",
            "Carbs",
            "Sugars",
            "Potassium",
            "Vitamins",
            "Rating"});
            this.searchByBox.Location = new System.Drawing.Point(245, 21);
            this.searchByBox.Name = "searchByBox";
            this.searchByBox.Size = new System.Drawing.Size(199, 33);
            this.searchByBox.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.reverseButton);
            this.panel1.Location = new System.Drawing.Point(140, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 70);
            this.panel1.TabIndex = 10;
            // 
            // reverseButton
            // 
            this.reverseButton.AutoSize = true;
            this.reverseButton.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.reverseButton.Location = new System.Drawing.Point(33, 14);
            this.reverseButton.Name = "reverseButton";
            this.reverseButton.Size = new System.Drawing.Size(187, 42);
            this.reverseButton.TabIndex = 11;
            this.reverseButton.TabStop = true;
            this.reverseButton.Text = "Reverse List";
            this.reverseButton.UseVisualStyleBackColor = true;
            // 
            // searchButton
            // 
            this.searchButton.BackColor = System.Drawing.Color.Gray;
            this.searchButton.Enabled = false;
            this.searchButton.Location = new System.Drawing.Point(76, 76);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(403, 59);
            this.searchButton.TabIndex = 4;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.resetButton);
            this.groupBox2.Location = new System.Drawing.Point(1395, 652);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(505, 154);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reset";
            // 
            // resetButton
            // 
            this.resetButton.BackColor = System.Drawing.Color.Gray;
            this.resetButton.Enabled = false;
            this.resetButton.Location = new System.Drawing.Point(71, 52);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(395, 71);
            this.resetButton.TabIndex = 0;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = false;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(695, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(558, 120);
            this.label2.TabIndex = 3;
            this.label2.Text = "Cereal Killers";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(515, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 149);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1289, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(245, 149);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel1);
            this.groupBox3.Controls.Add(this.searchButton);
            this.groupBox3.Location = new System.Drawing.Point(1382, 826);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(518, 167);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search Box";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 25);
            this.label10.TabIndex = 20;
            this.label10.Text = "Search 1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(516, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 25);
            this.label11.TabIndex = 21;
            this.label11.Text = "Search 2:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(29, 241);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 25);
            this.label12.TabIndex = 22;
            this.label12.Text = "Search 3:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(516, 241);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 25);
            this.label13.TabIndex = 23;
            this.label13.Text = "Search 4:";
            // 
            // CerealKiller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cerealGrid);
            this.Name = "CerealKiller";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.cerealGrid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView cerealGrid;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox searchByBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.RadioButton greaterButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn mfr;
        private System.Windows.Forms.DataGridViewTextBoxColumn type;
        private System.Windows.Forms.DataGridViewTextBoxColumn calories;
        private System.Windows.Forms.DataGridViewTextBoxColumn protein;
        private System.Windows.Forms.DataGridViewTextBoxColumn fat;
        private System.Windows.Forms.DataGridViewTextBoxColumn sodium;
        private System.Windows.Forms.DataGridViewTextBoxColumn fiber;
        private System.Windows.Forms.DataGridViewTextBoxColumn carbs;
        private System.Windows.Forms.DataGridViewTextBoxColumn sugars;
        private System.Windows.Forms.DataGridViewTextBoxColumn potassium;
        private System.Windows.Forms.DataGridViewTextBoxColumn vitamins;
        private System.Windows.Forms.DataGridViewTextBoxColumn shelf;
        private System.Windows.Forms.DataGridViewTextBoxColumn weight;
        private System.Windows.Forms.DataGridViewTextBoxColumn cups;
        private System.Windows.Forms.DataGridViewTextBoxColumn rating;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton lessButton;
        private System.Windows.Forms.TextBox valueBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton equalButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton reverseButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.RadioButton equalButton2;
        private System.Windows.Forms.TextBox valueBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton lessButton2;
        private System.Windows.Forms.RadioButton greaterButton2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox searchByBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton equalButton4;
        private System.Windows.Forms.TextBox valueBox4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton lessButton4;
        private System.Windows.Forms.RadioButton greaterButton4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox searchByBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton equalButton3;
        private System.Windows.Forms.TextBox valueBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton lessButton3;
        private System.Windows.Forms.RadioButton greaterButton3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox searchByBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
    }
}

