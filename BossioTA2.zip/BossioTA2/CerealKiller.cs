﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BossioTA2
{
    public partial class CerealKiller : Form
    {
        // global dictionary of cereals
        // values and keys are read from cereal.csv file
        static Dictionary<string, Cereal> cereals = new Dictionary<string, Cereal>();

        public CerealKiller()
        {
            // the controller for the form
            InitializeComponent();
            ReadCerealObj();
            AddData();
            searchByBox.TextChanged += CheckAllBoxesHandler;
            equalButton.CheckedChanged += CheckAllBoxesHandler;
            lessButton.CheckedChanged += CheckAllBoxesHandler;
            greaterButton.CheckedChanged += CheckAllBoxesHandler;
            valueBox.TextChanged += CheckAllBoxesHandler;
        }

        /// <summary>
        /// Event handler that waits for search box to be changed and activates
        /// search button
        /// </summary>
        public void CheckAllBoxesHandler(object sender, EventArgs e)
        {
            ActivateSearchButon();
        }

        /// <summary>
        /// Method that happens on search button click
        /// activates reset button and begins search
        /// </summary>
        private void searchButton_Click(object sender, EventArgs e)
        {
            ActivateResetButton();
            SearchByCriteria();
            reverseButton.Checked = false;
        }

        /// <summary>
        /// Method that happens on reset button click
        /// resets datafieldgrid and resets search field and button
        /// </summary>
        private void resetButton_Click(object sender, EventArgs e)
        {
            cerealGrid.Rows.Clear();
            AddData();
            ClearAll();
            TurnOffSearchButton();
        }

        /// <summary>
        /// Method for clearing all buttons and text boxes
        /// </summary>
        private void ClearAll()
        {
            searchByBox.Text = "";
            valueBox.Text = "";
            greaterButton.Checked = false;
            lessButton.Checked = false;
            equalButton.Checked = false;
            reverseButton.Checked = false;
            searchByBox2.Text = "";
            valueBox2.Text = "";
            greaterButton2.Checked = false;
            lessButton2.Checked = false;
            equalButton2.Checked = false;
            searchByBox3.Text = "";
            valueBox3.Text = "";
            greaterButton3.Checked = false;
            lessButton3.Checked = false;
            equalButton3.Checked = false;
            searchByBox4.Text = "";
            valueBox4.Text = "";
            greaterButton4.Checked = false;
            lessButton4.Checked = false;
            equalButton4.Checked = false;
        }

        /// <summary>
        /// Method for activating search button
        /// </summary>
        public void ActivateSearchButon()
        {
            // if all fields have data open search button
            if ((equalButton.Checked || lessButton.Checked || greaterButton.Checked) && valueBox.TextLength > 0 && searchByBox.SelectedIndex != -1)
            {
                searchButton.Enabled = true;
                searchButton.BackColor = Color.Cyan;
            }
            else
            {
                searchButton.Enabled = false;
                searchButton.BackColor = Color.Gray;
            }
        }

        /// <summary>
        /// Method for activating reset button
        /// </summary>
        public void ActivateResetButton()
        {
            resetButton.Enabled = true;
            resetButton.BackColor = Color.Cyan;
        }

        /// <summary>
        /// Method for disabeling search button and reset buttong
        /// </summary>
        public void TurnOffSearchButton()
        {
            searchButton.Enabled = false;
            searchButton.BackColor = Color.Gray;
            resetButton.Enabled = false;
            resetButton.BackColor = Color.Gray;
        }

        /// <summary>
        /// The method that does the main searching of the cereals.
        /// Uses switch statement to determine search criteria and creates a
        /// LINQ query based on criteria
        /// </summary>
        public void SearchByCriteria()
        {
            // clears grid and gets criteria
            cerealGrid.Rows.Clear();
            string criteria = searchByBox.Text;
            // initialize base query for cereal
            var result = from cereal in cereals
                         select cereal;
            // parses double value from string value Box
            double searchValue = double.Parse(valueBox.Text);

            // if equal button clicked
            if (equalButton.Checked)
            {
                // call method that runs query for equal to search value
                result = IsEqualCriteria(criteria, result, searchValue, cereals);
            }
            // if greater button checked show only greater than value box
            else if (greaterButton.Checked)
            {
                // call method that runs query for greater than search value
                result = IsGreaterCriteria(criteria, result, searchValue, cereals);
            }
            // if less button checked show only less than value box
            else if (lessButton.Checked)
            {
                // call method that runs query for less than search value
                result = IsLessCriteria(criteria, result, searchValue, cereals);
            }
            // if the second nutrient fact is selected a new result is returned
            result = SearchByOtherCriteria(result, searchByBox2, valueBox2, greaterButton2, lessButton2, equalButton2);

            // if the third nutrient fact is selected a new result is returned
            result = SearchByOtherCriteria(result, searchByBox3, valueBox3, greaterButton3, lessButton3, equalButton3);

            // if the fourth nutrient fact is selected a new result is returned
            result = SearchByOtherCriteria(result, searchByBox4, valueBox4, greaterButton4, lessButton4, equalButton4);

            // if reverse button checked reverse query a new result is returned
            if (reverseButton.Checked)
            {
                result = result.Reverse();
            }
            // adds each cereal to grid in sorted order by criteria
            foreach (var cereal in result)
            {
                cerealGrid.Rows.Add(cereal.Value.Name, cereal.Value.Mfr, cereal.Value.Type, cereal.Value.Calories, cereal.Value.Protien, cereal.Value.Fat, cereal.Value.Sodium,
                    cereal.Value.Fiber, cereal.Value.Carbo, cereal.Value.Sugars, cereal.Value.Potass, cereal.Value.Vitamins, cereal.Value.Shelf,
                    cereal.Value.Weight, cereal.Value.Cups, cereal.Value.Rating);
            }
        }

        /// <summary>
        /// Method that checks if a searchByBox 2, 3, or 4 has been filled
        /// Checks if greater, less, or equal button has been checked and runs query with valueBox
        /// Returns new query
        /// </summary>
        /// <param name="result"></param>
        /// <param name="searchByBoxM"></param>
        /// <param name="valueBoxM"></param>
        /// <param name="greaterButtonM"></param>
        /// <param name="lessButtonM"></param>
        /// <param name="equalButtonM"></param>
        /// <returns></returns>
        private IEnumerable<KeyValuePair<string, Cereal>> SearchByOtherCriteria(IEnumerable<KeyValuePair<string, Cereal>> result, ComboBox searchByBoxM, TextBox valueBoxM, RadioButton greaterButtonM,
                                                                                    RadioButton lessButtonM, RadioButton equalButtonM)
        {
            if (searchByBoxM.Text.Length > 0)
            {
                // get criteria from search box 
                string criteria = searchByBoxM.Text;
                // parses double value from string value Box
                double searchValue = double.Parse(valueBoxM.Text);

                // convert last query to a dictionary to be queried again
                Dictionary<string, Cereal> resultDict = result.ToDictionary(k => k.Key, k => k.Value);

                // if equal button clicked
                if (equalButtonM.Checked)
                {
                    // call method that runs query for equal to search value
                    result = IsEqualCriteria(criteria, result, searchValue, resultDict);
                }
                // if greater button checked show only greater than value box
                else if (greaterButtonM.Checked)
                {
                    // call method that runs query for greater than search value
                    result = IsGreaterCriteria(criteria, result, searchValue, resultDict);
                }
                // if less button checked show only less than value box
                else if (lessButtonM.Checked)
                {
                    // call method that runs query for less than search value
                    result = IsLessCriteria(criteria, result, searchValue, resultDict);
                }
            }

            return result;
        }

        /// <summary>
        /// Method for determining which nutrient fact is selected 
        /// Returns query of all of that nutrient facts is less than search value
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="result"></param>
        /// <param name="searchValue"></param>
        /// <returns></returns>
        private static IEnumerable<KeyValuePair<string, Cereal>> IsLessCriteria(string criteria, IEnumerable<KeyValuePair<string, Cereal>> result, double searchValue, Dictionary<string, Cereal> cerealList)
        {
            // creates new query based on search criteria
            switch (criteria)
            {
                case "Calories":
                    result = from cereal in cerealList
                             orderby cereal.Value.Calories
                             where cereal.Value.Calories < searchValue
                             select cereal;
                    break;
                case "Protein":
                    result = from cereal in cerealList
                             orderby cereal.Value.Protien
                             where cereal.Value.Protien < searchValue
                             select cereal;
                    break;
                case "Fat":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fat
                             where cereal.Value.Fat < searchValue
                             select cereal;
                    break;
                case "Sodium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sodium
                             where cereal.Value.Sodium < searchValue
                             select cereal;
                    break;
                case "Fiber":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fiber
                             where cereal.Value.Fiber < searchValue
                             select cereal;
                    break;
                case "Carbs":
                    result = from cereal in cerealList
                             orderby cereal.Value.Carbo
                             where cereal.Value.Carbo < searchValue
                             select cereal;
                    break;
                case "Sugars":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sugars
                             where cereal.Value.Sugars < searchValue
                             select cereal;
                    break;
                case "Potassium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Potass
                             where cereal.Value.Potass < searchValue
                             select cereal;
                    break;
                case "Vitamins":
                    result = from cereal in cerealList
                             orderby cereal.Value.Vitamins
                             where cereal.Value.Vitamins < searchValue
                             select cereal;
                    break;
                case "Rating":
                    result = from cereal in cerealList
                             orderby cereal.Value.Rating
                             where cereal.Value.Rating < searchValue
                             select cereal;
                    break;
            }

            return result;
        }

        /// <summary>
        /// Method for determining which nutrient fact is selected 
        /// Returns query of all of that nutrient facts greater than search value
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="result"></param>
        /// <param name="searchValue"></param>
        /// <returns></returns>
        private static IEnumerable<KeyValuePair<string, Cereal>> IsGreaterCriteria(string criteria, IEnumerable<KeyValuePair<string, Cereal>> result, double searchValue, Dictionary<string, Cereal> cerealList)
        {
            // creates new query based on search criteria
            switch (criteria)
            {
                case "Calories":
                    result = from cereal in cerealList
                             orderby cereal.Value.Calories
                             where cereal.Value.Calories > searchValue
                             select cereal;
                    break;
                case "Protein":
                    result = from cereal in cerealList
                             orderby cereal.Value.Protien
                             where cereal.Value.Protien > searchValue
                             select cereal;
                    break;
                case "Fat":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fat
                             where cereal.Value.Fat > searchValue
                             select cereal;
                    break;
                case "Sodium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sodium
                             where cereal.Value.Sodium > searchValue
                             select cereal;
                    break;
                case "Fiber":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fiber
                             where cereal.Value.Fiber > searchValue
                             select cereal;
                    break;
                case "Carbs":
                    result = from cereal in cerealList
                             orderby cereal.Value.Carbo
                             where cereal.Value.Carbo > searchValue
                             select cereal;
                    break;
                case "Sugars":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sugars
                             where cereal.Value.Sugars > searchValue
                             select cereal;
                    break;
                case "Potassium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Potass
                             where cereal.Value.Potass > searchValue
                             select cereal;
                    break;
                case "Vitamins":
                    result = from cereal in cerealList
                             orderby cereal.Value.Vitamins
                             where cereal.Value.Vitamins > searchValue
                             select cereal;
                    break;
                case "Rating":
                    result = from cereal in cerealList
                             orderby cereal.Value.Rating
                             where cereal.Value.Rating > searchValue
                             select cereal;
                    break;
            }

            return result;
        }

        /// <summary>
        /// Method for determining which nutrient fact is selected 
        /// Returns query of all of that nutrient facts eual to search value
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="result"></param>
        /// <param name="searchValue"></param>
        /// <returns></returns>
        private static IEnumerable<KeyValuePair<string, Cereal>> IsEqualCriteria(string criteria, IEnumerable<KeyValuePair<string, Cereal>> result, double searchValue, Dictionary<string, Cereal> cerealList)
        {
            // creates new query based on search criteria
            switch (criteria)
            {
                case "Calories":
                    result = from cereal in cerealList
                             orderby cereal.Value.Calories
                             where cereal.Value.Calories == searchValue
                             select cereal;
                    break;
                case "Protein":
                    result = from cereal in cerealList
                             orderby cereal.Value.Protien
                             where cereal.Value.Protien == searchValue
                             select cereal;
                    break;
                case "Fat":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fat
                             where cereal.Value.Fat == searchValue
                             select cereal;
                    break;
                case "Sodium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sodium
                             where cereal.Value.Sodium == searchValue
                             select cereal;
                    break;
                case "Fiber":
                    result = from cereal in cerealList
                             orderby cereal.Value.Fiber
                             where cereal.Value.Fiber == searchValue
                             select cereal;
                    break;
                case "Carbs":
                    result = from cereal in cerealList
                             orderby cereal.Value.Carbo
                             where cereal.Value.Carbo == searchValue
                             select cereal;
                    break;
                case "Sugars":
                    result = from cereal in cerealList
                             orderby cereal.Value.Sugars
                             where cereal.Value.Sugars == searchValue
                             select cereal;
                    break;
                case "Potassium":
                    result = from cereal in cerealList
                             orderby cereal.Value.Potass
                             where cereal.Value.Potass == searchValue
                             select cereal;
                    break;
                case "Vitamins":
                    result = from cereal in cerealList
                             orderby cereal.Value.Vitamins
                             where cereal.Value.Vitamins == searchValue
                             select cereal;
                    break;
                case "Rating":
                    result = from cereal in cerealList
                             orderby cereal.Value.Rating
                             where cereal.Value.Rating == searchValue
                             select cereal;
                    break;
            }

            return result;
        }

        // adds base data to grid sorted by name
        public void AddData()
        {
            foreach (var cereal in cereals)
            {
                cerealGrid.Rows.Add(cereal.Value.Name, cereal.Value.Mfr, cereal.Value.Type, cereal.Value.Calories, cereal.Value.Protien, cereal.Value.Fat, cereal.Value.Sodium,
                    cereal.Value.Fiber, cereal.Value.Carbo, cereal.Value.Sugars, cereal.Value.Potass, cereal.Value.Vitamins, cereal.Value.Shelf,
                    cereal.Value.Weight, cereal.Value.Cups, cereal.Value.Rating);
            }
        }

        /// <summary>
        /// a method that reads from a csv file and
        /// creates cereal objects
        /// </summary>
        static void ReadCerealObj()
        {
            // exception handling in case of invalid file
            try
            {
                // creates variables used in method
                List<Cereal> listOfObjects = new List<Cereal>();
                int objCount = 0;

                // opens file for reading
                StreamReader reader = new StreamReader("cereal.csv");

                // while file not empty
                while (!reader.EndOfStream)
                {
                    // read line of file into array seperating comma
                    var values = reader.ReadLine().Split(',');

                    // ignore tags
                    if (objCount >= 1)
                    {
                        // instantiate cereal object with values
                        Cereal cereal = new Cereal(values[0], char.Parse(values[1]), char.Parse(values[2]), int.Parse(values[3]), int.Parse(values[4]), int.Parse(values[5])
                            , int.Parse(values[6]), double.Parse(values[7]), double.Parse(values[8]), int.Parse(values[9]), int.Parse(values[10]), int.Parse(values[11])
                            , int.Parse(values[12]), double.Parse(values[13]), double.Parse(values[14]), double.Parse(values[15]));

                        // add cereal object to list of objects
                        listOfObjects.Add(cereal);
                    }
                    objCount++;
                }
                // add cereal objects to dictionary
                // cereal name is key
                for (int i = 0; i < listOfObjects.Count; i++)
                {
                    cereals[listOfObjects[i].Name] = listOfObjects[i];
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
